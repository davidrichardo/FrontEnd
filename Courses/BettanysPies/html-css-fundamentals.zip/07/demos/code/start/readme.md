# HTML and CSS Fundamentals

## Setup

If you installed git you can clone the code to your machine, or download a ZIP of all the files directly.

[Download the ZIP from this location](https://github.com/craigshoemaker/html-css-fundamentals/archive/main.zip), or run the following [git](https://git-scm.com/downloads) command to clone the files to your machine:

```bash
git clone https://github.com/craigshoemaker/html-css-fundamentals
```

- Once the files are on your machine, open the _html-css-fundamentals_ folder in [Visual Studio Code](https://code.visualstudio.com/).
